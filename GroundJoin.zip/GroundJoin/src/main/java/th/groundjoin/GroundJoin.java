package th.groundjoin;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class GroundJoin extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        // รอ 5 tick ให้ผู้เล่นโหลดเสร็จก่อนค่อยวาป
        Bukkit.getScheduler().runTaskLater(this, () -> handle(p), 5L);
    }

    private void handle(Player p) {
        if (!p.isOnline()) return;

        // 1) วาปไปจุดสปอนของโลก EPIC ทุกครั้งที่เข้า
        String worldName = getConfig().getString("world", "EPIC");
        World epic = Bukkit.getWorld(worldName);
        if (epic == null) {
            getLogger().warning("ไม่พบโลกชื่อ '" + worldName + "'");
            return;
        }
        Location spawn = epic.getSpawnLocation().add(0.5, 0, 0.5);
        p.setFallDistance(0);
        p.teleport(spawn);

        // 2) ถ้าสปอนอยู่กลางอากาศ ให้วาปลงพื้น
        if (!p.hasPermission("groundjoin.bypass")) fixAir(p);
    }

    private void fixAir(Player p) {
        Location loc = p.getLocation();
        World w = loc.getWorld();

        Block below = loc.clone().subtract(0, 0.1, 0).getBlock();
        if (below.getType().isSolid() || below.isLiquid()) return;

        int x = loc.getBlockX(), z = loc.getBlockZ();
        for (int y = loc.getBlockY(); y >= w.getMinHeight(); y--) {
            Block b = w.getBlockAt(x, y, z);
            if (b.isLiquid()) return;
            if (b.getType().isSolid()) {
                boolean free = b.getRelative(0, 1, 0).isPassable()
                        && b.getRelative(0, 2, 0).isPassable();
                if (!free) continue;
                p.setFallDistance(0);
                p.teleport(new Location(w, x + 0.5, y + 1, z + 0.5,
                        loc.getYaw(), loc.getPitch()));
                p.sendMessage("§eคุณถูกวาปลงมาที่พื้น");
                return;
            }
        }
        p.setFallDistance(0);
        p.teleport(w.getSpawnLocation());
    }

    // ===================== ป้องกันโลก =====================

    private boolean isProtected(World w) {
        if (w == null) return false;
        String name = getConfig().getString("protected-world", "EPIC");
        return w.getName().equalsIgnoreCase(name);
    }

    private boolean canBuild(Player p) {
        return p.isOp() || p.hasPermission("groundjoin.build");
    }

    private void deny(Player p) {
        String msg = getConfig().getString("deny-message", "§cคุณไม่มีสิทธิ์ทำสิ่งนี้ในโลกนี้");
        if (!msg.isEmpty()) p.sendMessage(msg);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (isProtected(e.getBlock().getWorld()) && !canBuild(p)) {
            e.setCancelled(true);
            deny(p);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (isProtected(e.getBlock().getWorld()) && !canBuild(p)) {
            e.setCancelled(true);
            deny(p);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        Player p = e.getPlayer();
        if (isProtected(e.getBlock().getWorld()) && !canBuild(p)) {
            e.setCancelled(true);
            deny(p);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        Player p = e.getPlayer();
        if (isProtected(e.getBlock().getWorld()) && !canBuild(p)) {
            e.setCancelled(true);
            deny(p);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player)) return;
        if (!isProtected(e.getEntity().getWorld())) return;

        Entity damager = e.getDamager();
        if (damager instanceof Projectile) {
            Object shooter = ((Projectile) damager).getShooter();
            if (shooter instanceof Entity) damager = (Entity) shooter;
        }
        if (!(damager instanceof Player)) return;

        Player attacker = (Player) damager;
        // ห้ามตีกันทุกคน ยกเว้นเปิด allow-op-pvp ใน config และผู้ตีเป็น OP
        boolean opAllowed = getConfig().getBoolean("allow-op-pvp", false) && attacker.isOp();
        if (!opAllowed) {
            e.setCancelled(true);
            deny(attacker);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMobSpawn(CreatureSpawnEvent e) {
        if (!getConfig().getBoolean("block-mob-spawn", true)) return;
        if (!isProtected(e.getLocation().getWorld())) return;

        // ยังให้ OP เสกมอนเองได้ (spawn egg / คำสั่ง / ปลั๊กอิน)
        CreatureSpawnEvent.SpawnReason r = e.getSpawnReason();
        if (r == CreatureSpawnEvent.SpawnReason.CUSTOM
                || r == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG) return;

        e.setCancelled(true);
    }
}
